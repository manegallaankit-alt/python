import json, sys, tempfile, unittest
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

import analytics, storage, validation as v


class TestValidation(unittest.TestCase):
    def test_valid(self):
        rec, errs = v.validate_record({"text": "Hi there", "author": "A", "category": "life", "rating": "4"})
        self.assertEqual(errs, []); self.assertEqual(rec["rating"], 4)

    def test_invalid(self):
        _, errs = v.validate_record({"text": "", "category": "zzz", "rating": "9"})
        self.assertEqual(len(errs), 3)

    def test_clean_text(self):
        self.assertEqual(v.clean_text("  a \n\t b "), "a b")


class TestStorage(unittest.TestCase):
    def test_missing_file_creates_template(self):
        with tempfile.TemporaryDirectory() as d:
            p = Path(d) / "q.json"
            self.assertEqual(storage.load_quotes(p), []); self.assertTrue(p.exists())

    def test_corrupt_file_recovers(self):
        with tempfile.TemporaryDirectory() as d:
            p = Path(d) / "q.json"; p.write_text("{not json")
            self.assertEqual(storage.load_quotes(p), [])
            self.assertTrue((Path(d) / "q.corrupt.bak").exists())

    def test_roundtrip(self):
        with tempfile.TemporaryDirectory() as d:
            p = Path(d) / "q.json"; qs = []
            qs.append(storage.make_record(qs, "Hello world quote", "Me", "life", 5))
            storage.save_quotes(qs, p)
            self.assertEqual(storage.load_quotes(p), qs)

    def test_import_logs_errors(self):
        qs = []
        added, errs = storage.import_csv(storage.DATA_DIR / "legacy_import_sample.csv", qs)
        self.assertEqual(added, 3); self.assertEqual(len(errs), 5)


class TestAnalytics(unittest.TestCase):
    def setUp(self):
        self.q = json.loads((storage.DATA_DIR / "sample_quotes.json").read_text())

    def test_summary(self):
        s = analytics.summarize(self.q)
        self.assertEqual(s["total"], len(self.q)); self.assertTrue(1 <= s["avg_rating"] <= 5)

    def test_warnings_detect_edge_cases(self):
        w = " ".join(analytics.warnings(self.q))
        self.assertIn("Duplicate", w); self.assertIn("Anomalous length", w); self.assertIn("Low rating", w)

    def test_search(self):
        self.assertTrue(all(q["category"] == "humor" for q in analytics.search(self.q, "", "humor")))
        self.assertTrue(analytics.search(self.q, "wilde"))


if __name__ == "__main__":
    unittest.main()
