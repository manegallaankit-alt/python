#!/usr/bin/env python3
"""Quote of the Day App - menu-driven terminal application."""
import shutil
import sys
from pathlib import Path

import analytics
import api
import export
import plotting
import storage
import ui
import validation as v

LEGACY_SAMPLE = storage.DATA_DIR / "legacy_import_sample.csv"


def fetch_flow(quotes):
    print("Fetching today's quote...")
    q, origin = api.fetch_quote()
    if origin == "cache":
        print(ui.yellow("  (Offline or API unavailable - using local mock cache)"))
    ui.show_quote({**q, "category": "-", "rating": 0})
    if storage.is_duplicate(quotes, q["text"]):
        print(ui.yellow("Already in your favourites."))
        return
    if v.ask_yes_no("Save to favourites?", default=True):
        cat = v.ask_category()
        rating = v.ask_int("Rating 1-5 (Enter = 3): ", 1, 5, default=3)
        rec = storage.make_record(quotes, q["text"], q["author"], cat, rating, source=origin)
        quotes.append(rec)
        storage.save_quotes(quotes)
        print(ui.green(f"Saved as #{rec['id']}."))


def add_flow(quotes):
    text = v.ask_text("Quote text: ", min_len=5)
    if storage.is_duplicate(quotes, text):
        print(ui.yellow("That quote already exists."))
        return
    author = v.ask_text("Author (Enter = Unknown): ", max_len=v.MAX_AUTHOR_LEN, default="Unknown")
    cat = v.ask_category()
    rating = v.ask_int("Rating 1-5: ", 1, 5)
    rec = storage.make_record(quotes, text, author, cat, rating)
    quotes.append(rec)
    storage.save_quotes(quotes)
    print(ui.green(f"Saved as #{rec['id']}."))


def search_flow(quotes):
    kw = v.ask_text("Keyword (Enter = any): ", allow_blank=True)
    cat = ""
    if v.ask_yes_no("Filter by category?"):
        cat = v.ask_category(default="")
    results = analytics.search(quotes, kw, cat)
    print(f"\n{len(results)} match(es)")
    ui.paginate(results)


def delete_flow(quotes):
    qid = v.ask_int("ID to delete: ", 1, 10**9)
    match = next((q for q in quotes if q["id"] == qid), None)
    if not match:
        print(ui.red("No quote with that ID."))
        return
    ui.show_quote(match)
    if v.ask_yes_no("Delete this quote?"):
        quotes.remove(match)
        storage.save_quotes(quotes)
        print(ui.green("Deleted."))


def summary_flow(quotes):
    s = analytics.summarize(quotes)
    if not s:
        print(ui.yellow("No data yet. Add quotes or load sample data (option 10)."))
        return
    print(ui.bold("\n=== EXECUTIVE SUMMARY ==="))
    print(f"Total quotes   : {s['total']}")
    print(f"Average rating : {s['avg_rating']:.2f}/5")
    print(f"Average length : {s['avg_length']:.0f} chars")
    print(f"Status         : {ui.green(s['status']) if s['avg_rating'] >= 3 else ui.red(s['status'])}")
    print("\nBy category:")
    for k, n in s["by_category"].items():
        print(f"  {k:<11}{'#' * n} {n}")
    print("\nRating distribution:")
    for r, n in s["rating_dist"].items():
        print(f"  {r} star  {'#' * n} {n}")
    print("\nTop authors: " + ", ".join(f"{a} ({n})" for a, n in s["top_authors"]))
    print("Monthly trend: " + ", ".join(f"{m}: {n}" for m, n in s["by_month"].items()))
    top = s["top_quote"]
    print(f'Top rated: "{ui.truncate(top["text"], 60)}" - {top["author"]}')
    warns = analytics.warnings(quotes)
    if warns:
        print(ui.yellow(f"\n! {len(warns)} warning(s):"))
        for w in warns[:8]:
            print(ui.yellow("  - " + w))
        if len(warns) > 8:
            print(ui.yellow(f"  ... and {len(warns) - 8} more (see exported audit log)"))


def charts_flow(quotes):
    files = plotting.make_charts(quotes)
    for f in files:
        print(ui.green(f"Saved {f.relative_to(storage.BASE_DIR)}"))


def export_flow(quotes):
    files = export.export_all(quotes)
    if not files:
        print(ui.yellow("Nothing to export."))
    for f in files:
        print(ui.green(f"Exported {f.relative_to(storage.BASE_DIR)}"))


def import_flow(quotes):
    path = v.ask_text(f"CSV path (Enter = {LEGACY_SAMPLE.name}): ", allow_blank=True) or str(LEGACY_SAMPLE)
    added, errors = storage.import_csv(path, quotes, storage.BASE_DIR / "reports" / "import_errors.log")
    storage.save_quotes(quotes)
    print(ui.green(f"Imported {added} row(s)."))
    if errors:
        print(ui.yellow(f"{len(errors)} problem(s) - logged to reports/import_errors.log:"))
        for e in errors[:6]:
            print(ui.yellow("  - " + e))


def sample_flow(quotes):
    if quotes and not v.ask_yes_no("This replaces your current data. Continue?"):
        return
    shutil.copy(storage.SAMPLE_FILE, storage.QUOTES_FILE)
    quotes[:] = storage.load_quotes()
    print(ui.green(f"Loaded {len(quotes)} sample quotes."))


MENU = [
    ("1", "Fetch quote of the day (API)", fetch_flow),
    ("2", "Add a quote manually", add_flow),
    ("3", "View all quotes", lambda q: ui.paginate(q)),
    ("4", "Search / filter", search_flow),
    ("5", "Delete a quote", delete_flow),
    ("6", "Executive summary", summary_flow),
    ("7", "Generate charts (PNG)", charts_flow),
    ("8", "Export reports (MD / TXT / CSV)", export_flow),
    ("9", "Bulk import from CSV", import_flow),
    ("10", "Load sample dataset", sample_flow),
]


def main():
    ui.banner()
    quotes = storage.load_quotes()
    print(f"Loaded {len(quotes)} saved quote(s).")
    actions = {k: fn for k, _, fn in MENU}
    while True:
        print(ui.bold("\nMAIN MENU"))
        for k, label, _ in MENU:
            print(f"  {k:>2}. {label}")
        print("   0. Exit")
        try:
            choice = input("Choose an option: ").strip()
        except (EOFError, KeyboardInterrupt):
            print("\nGoodbye!")
            return
        if choice == "0":
            print("Goodbye! Your quotes are saved.")
            return
        if choice not in actions:
            print(ui.red("  ! Invalid option - enter a number from the menu."))
            continue
        try:
            actions[choice](quotes)
        except (EOFError, KeyboardInterrupt):
            print("\nCancelled.")
        except Exception as err:  # last-resort guard so the demo never crashes
            print(ui.red(f"  ! Unexpected error: {err}"))


if __name__ == "__main__":
    sys.exit(main())
