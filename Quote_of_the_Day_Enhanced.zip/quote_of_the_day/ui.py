"""Console helpers: ANSI colours, banner, fixed-width tables, pagination."""
import os
import sys

USE_COLOR = sys.stdout.isatty() and os.environ.get("NO_COLOR") is None


def c(text, code):
    return f"\033[{code}m{text}\033[0m" if USE_COLOR else str(text)


def green(t): return c(t, "92")
def red(t): return c(t, "91")
def yellow(t): return c(t, "93")
def cyan(t): return c(t, "96")
def bold(t): return c(t, "1")


def banner():
    line = "=" * 58
    print(cyan(line))
    print(cyan("   QUOTE OF THE DAY  -  fetch, save & analyse quotes"))
    print(cyan("   GreenFuture Hack | Project #113"))
    print(cyan(line))


def truncate(text, width):
    text = str(text)
    return text if len(text) <= width else text[: width - 3] + "..."


def print_table(quotes, start_index=0):
    header = f"{'ID':>4} | {'Quote':<38} | {'Author':<16} | {'Category':<10} | {'Rt':>2}"
    print(bold(header))
    print("-" * len(header))
    for q in quotes:
        print(
            f"{q['id']:>4} | {truncate(q['text'], 38):<38} | "
            f"{truncate(q['author'], 16):<16} | {truncate(q['category'], 10):<10} | {q['rating']:>2}"
        )


def paginate(quotes, page_size=10):
    """Show quotes page by page; Enter = next, q = quit."""
    if not quotes:
        print(yellow("No quotes to show."))
        return
    total_pages = (len(quotes) + page_size - 1) // page_size
    for page in range(total_pages):
        chunk = quotes[page * page_size:(page + 1) * page_size]
        print_table(chunk)
        print(f"\nPage {page + 1}/{total_pages}  ({len(quotes)} quotes)")
        if page < total_pages - 1:
            if input("Enter = next page, q = stop: ").strip().lower() == "q":
                break


def show_quote(q):
    print()
    print(f'  "{q["text"]}"')
    print(f"   - {q['author']}   [{q['category']}]  rating {q['rating']}/5")
    print()
