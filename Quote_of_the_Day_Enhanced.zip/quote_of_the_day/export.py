"""Multi-format summary export: Markdown, plain-text audit log, CSV."""
from datetime import datetime
from pathlib import Path

from analytics import summarize, warnings
from storage import export_csv

REPORT_DIR = Path(__file__).resolve().parent / "reports"


def export_all(quotes, out_dir=REPORT_DIR):
    s = summarize(quotes)
    if not s:
        return []
    out_dir = Path(out_dir); out_dir.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    warns = warnings(quotes)

    md = out_dir / f"summary_{stamp}.md"
    lines = ["# Quote of the Day - Summary Report", f"_Generated {datetime.now():%Y-%m-%d %H:%M}_", "",
             f"- **Total quotes:** {s['total']}", f"- **Average rating:** {s['avg_rating']:.2f}/5",
             f"- **Average length:** {s['avg_length']:.0f} characters", f"- **Status:** {s['status']}", "",
             "## By category", "| Category | Count |", "|---|---|"]
    lines += [f"| {k} | {v} |" for k, v in s["by_category"].items()]
    lines += ["", "## Top authors"] + [f"- {a} ({n})" for a, n in s["top_authors"]]
    lines += ["", "## Warnings"] + ([f"- {w}" for w in warns] or ["- None"])
    md.write_text("\n".join(lines), encoding="utf-8")

    txt = out_dir / f"audit_log_{stamp}.txt"
    log = [f"AUDIT LOG {datetime.now():%Y-%m-%d %H:%M:%S}", f"Records: {s['total']}", ""]
    log += [f"#{q['id']:>3} {q['date_added']} [{q['source']}] {q['author']}: {q['text'][:60]}" for q in quotes]
    log += ["", "WARNINGS:"] + (warns or ["none"])
    txt.write_text("\n".join(log), encoding="utf-8")

    csv_path = out_dir / f"quotes_{stamp}.csv"
    export_csv(quotes, csv_path)
    return [md, txt, csv_path]
